"""
app.py  -  Reinforcement Learning-Based Smart Traffic Signal Control System
===========================================================================
Run with:   streamlit run app.py

Files of the project
  app.py          -> this dashboard (user interface)
  traffic_env.py  -> intersection simulation (deque queues, dicts, tuples)
  q_agent.py      -> Q-learning agent (Q-table is a dict)
  trainer.py      -> training loop, fixed-time baseline, evaluation
"""

import pandas as pd
import streamlit as st

from q_agent import QLearningAgent
from traffic_env import (DEFAULT_RATES, DIRECTIONS, LEVEL_NAMES, MAX_QUEUE,
                         TrafficIntersection)
from trainer import evaluate, fixed_time_action, train

# ----------------------------------------------------------------- theme colours
NAVY, PANEL, BORDER = "#0A1128", "#111C3D", "#1E3A8A"
BLUE, LIGHT_BLUE, GREEN = "#3B82F6", "#60A5FA", "#22C55E"
TEXT, MUTED, RED, AMBER = "#E6EDF7", "#94A3B8", "#EF4444", "#F59E0B"
CHART_COLORS = [BLUE, GREEN, "#22D3EE", AMBER]

RL_MODE, FIXED_MODE = "Q-learning agent", "Fixed-time baseline"

st.set_page_config(page_title="RL Smart Traffic Signal Control",
                   page_icon="🚦", layout="wide")

st.markdown(f"""
<style>
.stApp {{ background: radial-gradient(circle at top left, #12235a 0%, {NAVY} 45%); color: {TEXT}; }}
[data-testid="stSidebar"] {{ background: #0C1636; border-right: 1px solid {BORDER}; }}
header[data-testid="stHeader"] {{ background: transparent; }}
h1, h2, h3, h4 {{ color: {TEXT}; }}
div.stButton > button, div.stDownloadButton > button {{
  width: 100%; border: none; border-radius: 10px; font-weight: 600; color: white;
  background: linear-gradient(90deg, #2563EB, #1D4ED8); padding: 0.55rem 0.8rem;
  transition: all .15s ease-in-out; }}
div.stButton > button:hover, div.stDownloadButton > button:hover {{
  background: linear-gradient(90deg, #16A34A, {GREEN}); color: #04210f;
  transform: translateY(-1px); box-shadow: 0 6px 18px rgba(34,197,94,.35); }}
.hero {{ background: linear-gradient(100deg, #12235a, #0f3b4a); border: 1px solid {BORDER};
  border-radius: 16px; padding: 18px 24px; margin-bottom: 14px; }}
.hero h1 {{ margin: 0; font-size: 1.7rem; }}
.hero p {{ margin: 4px 0 0; color: {MUTED}; }}
.kpi {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 14px;
  padding: 12px 14px; border-top: 3px solid var(--accent); }}
.kpi .label {{ color: {MUTED}; font-size: .75rem; text-transform: uppercase; letter-spacing: .06em; }}
.kpi .value {{ font-size: 1.55rem; font-weight: 700; color: {TEXT}; line-height: 1.25; }}
.kpi .sub {{ color: {MUTED}; font-size: .72rem; }}
.qcard {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 12px;
  padding: 10px 14px; margin-bottom: 10px; }}
.qcard.green {{ border-color: {GREEN}; box-shadow: 0 0 14px rgba(34,197,94,.25); }}
.qrow {{ display: flex; justify-content: space-between; font-weight: 600; }}
.qbar {{ background: #0A1128; border-radius: 8px; height: 10px; margin-top: 6px; overflow: hidden; }}
.qfill {{ height: 100%; border-radius: 8px; }}
.badge {{ font-size: .7rem; padding: 2px 8px; border-radius: 20px; font-weight: 700; }}
button[data-baseweb="tab"] {{ color: {MUTED}; }}
button[data-baseweb="tab"][aria-selected="true"] {{ color: {GREEN}; }}
</style>
""", unsafe_allow_html=True)


# ------------------------------------------------------------ session handling
def new_environment(seed):
    """A fresh intersection with 3 vehicles waiting on every road."""
    env = TrafficIntersection(seed=int(seed))
    for d in DIRECTIONS:
        env.add_vehicles(d, 3)
    return env


def init_session():
    ss = st.session_state
    if "env" not in ss:
        ss.env = new_environment(42)
        ss.agent = QLearningAgent(seed=1)
        ss.history = []          # list of dicts, one per simulated step
        ss.train_rewards = []    # list of total reward per training episode
        ss.comparison = None     # result of "RL vs fixed-time" comparison


init_session()


def simulate_step(mode):
    """Run ONE step with the chosen controller and store it in the history list."""
    ss = st.session_state
    env, agent = ss.env, ss.agent
    state = env.get_state()
    if mode == RL_MODE:
        action = agent.choose_action(state, explore=False)   # greedy: use what was learned
    else:
        action = fixed_time_action(env.step_count)
    _next_state, reward, info = env.step(action)

    previous_total = ss.history[-1]["cumulative_reward"] if ss.history else 0.0
    record = {
        "step": env.step_count,
        "controller": "Q-learning" if mode == RL_MODE else "Fixed-time",
        "signal": info["signal"],
        **{d: info["queues"][d] for d in DIRECTIONS},      # queue size after the step
        "total_queue": info["total_queue"],
        "cleared": info["cleared"],
        "arrived": info["arrived"],
        "reward": round(reward, 2),
        "cumulative_reward": round(previous_total + reward, 2),
    }
    ss.history.append(record)


def run_training(alpha, gamma, eps_start, episodes, steps):
    ss = st.session_state
    agent = ss.agent
    agent.alpha, agent.gamma = alpha, gamma
    bar = st.progress(0.0, text="Training the agent...")

    def on_progress(done, total, reward):
        if done % 5 == 0 or done == total:
            bar.progress(done / total, text=f"Episode {done}/{total}  |  reward {reward:,.0f}")

    rewards = train(agent, episodes, steps, eps_start,
                    seed=len(ss.train_rewards) + 7, progress_callback=on_progress)
    ss.train_rewards.extend(rewards)
    bar.empty()
    st.success(f"Training finished: {episodes} episodes. "
               f"The Q-table now holds {len(agent.q_table):,} states.")


# ------------------------------------------------------------------- SVG scene
CAR_COLORS = ["#3B82F6", "#60A5FA", "#22C55E", "#94A3B8", "#38BDF8", "#A78BFA"]
MAX_VISIBLE_CARS = 5


def car_geometry(direction, i):
    """(x, y, width, height, move_dx, move_dy) of the i-th car in a queue."""
    if direction == "North":
        return 262, 208 - 42 * i, 26, 36, 0, 70
    if direction == "South":
        return 312, 356 + 42 * i, 26, 36, 0, -70
    if direction == "East":
        return 356 + 42 * i, 262, 36, 26, -70, 0
    return 208 - 42 * i, 312, 36, 26, 70, 0            # West


def traffic_light(x, y, label, is_green):
    red = "#3A1C28" if is_green else RED
    green = GREEN if is_green else "#143024"
    glow = ' class="glow"' if is_green else ""
    return (f'<rect x="{x}" y="{y}" width="26" height="58" rx="7" fill="#070D22" stroke="#2B3F7A"/>'
            f'<circle cx="{x + 13}" cy="{y + 17}" r="8" fill="{red}"/>'
            f'<circle cx="{x + 13}" cy="{y + 41}" r="8" fill="{green}"{glow}/>'
            f'<text x="{x + 13}" y="{y - 6}" text-anchor="middle" fill="{MUTED}" '
            f'font-size="12" font-weight="700">{label}</text>')


def intersection_html(queues, signal):
    """Build the animated four-way intersection as an SVG inside a small HTML page."""
    p = []
    p.append(f'<rect width="600" height="600" rx="18" fill="#0C1738"/>')
    p.append('<rect x="250" y="0" width="100" height="600" fill="#18264D"/>')
    p.append('<rect x="0" y="250" width="600" height="100" fill="#18264D"/>')
    for x1, y1, x2, y2 in [(300, 0, 300, 250), (300, 350, 300, 600),
                           (0, 300, 250, 300), (350, 300, 600, 300)]:
        p.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#F59E0B" '
                 f'stroke-width="3" stroke-dasharray="14 12" opacity=".8"/>')
    for x, y, w, h in [(250, 246, 50, 4), (300, 350, 50, 4), (350, 250, 4, 50), (246, 300, 4, 50)]:
        p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#E6EDF7" opacity=".85"/>')

    arrows = {"North": "▼", "South": "▲", "East": "◀", "West": "▶"}
    if signal:
        p.append(f'<text x="300" y="320" text-anchor="middle" font-size="46" fill="{GREEN}" '
                 f'class="glow">{arrows[signal]}</text>')

    # cars: only the first few are drawn, the rest are shown as "+N"
    for d in DIRECTIONS:
        queue = list(queues[d])
        for i, (vehicle_id, _arrival) in enumerate(queue[:MAX_VISIBLE_CARS]):
            x, y, w, h, dx, dy = car_geometry(d, i)
            color = CAR_COLORS[vehicle_id % len(CAR_COLORS)]
            moving = "go" if d == signal else ""
            if h > w:
                window = f'<rect x="{x + 4}" y="{y + 8}" width="{w - 8}" height="9" rx="3" fill="#0A1128" opacity=".55"/>'
            else:
                window = f'<rect x="{x + 8}" y="{y + 4}" width="9" height="{h - 8}" rx="3" fill="#0A1128" opacity=".55"/>'
            p.append(f'<g class="{moving}" style="--dx:{dx}px;--dy:{dy}px;animation-delay:{i * 0.12}s">'
                     f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="7" fill="{color}"/>{window}</g>')
        extra = len(queue) - MAX_VISIBLE_CARS
        if extra > 0:
            x, y, w, h, _dx, _dy = car_geometry(d, MAX_VISIBLE_CARS)
            p.append(f'<text x="{x + w / 2}" y="{y + h / 2 + 5}" text-anchor="middle" '
                     f'fill="{TEXT}" font-size="14" font-weight="700">+{extra}</text>')

    # traffic lights (one per road) and count labels
    for (x, y), d in zip([(214, 182), (362, 362), (362, 182), (214, 362)], DIRECTIONS):
        p.append(traffic_light(x, y, d[0], d == signal))
    labels = {"North": (345, 24, "start"), "South": (255, 588, "end"),
              "East": (588, 236, "end"), "West": (12, 378, "start")}
    for d, (x, y, anchor) in labels.items():
        color = GREEN if d == signal else LIGHT_BLUE
        p.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" fill="{color}" '
                 f'font-size="16" font-weight="700">{d.upper()} · {len(queues[d])}</text>')

    css = ("html,body{margin:0;height:100%;background:transparent;}"
           "svg{width:100%;height:100%;display:block;}"
           "@keyframes pulse{0%,100%{opacity:1}50%{opacity:.45}}"
           "@keyframes go{0%{transform:translate(0,0);opacity:1}"
           "100%{transform:translate(var(--dx),var(--dy));opacity:.15}}"
           ".glow{animation:pulse 1.2s infinite;filter:drop-shadow(0 0 7px #22C55E)}"
           ".go{animation:go 1.4s ease-in infinite}")
    return (f"<style>{css}</style>"
            f'<svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">{"".join(p)}</svg>')


def show_html(html, height):
    """Show an HTML page in an iframe (st.iframe on new Streamlit, components.html on old)."""
    if hasattr(st, "iframe"):
        st.iframe(html, height=height)
    else:
        import streamlit.components.v1 as components
        components.html(html, height=height)


# ------------------------------------------------------------------ small HTML helpers
def kpi(label, value, sub="", accent=BLUE):
    return (f'<div class="kpi" style="--accent:{accent}"><div class="label">{label}</div>'
            f'<div class="value">{value}</div><div class="sub">{sub}</div></div>')


def queue_card(direction, count, is_green):
    percent = min(count / 20, 1.0) * 100
    color = GREEN if is_green else (RED if count >= 13 else (AMBER if count >= 7 else BLUE))
    badge = (f'<span class="badge" style="background:{GREEN};color:#04210f">GREEN</span>'
             if is_green else
             f'<span class="badge" style="background:#3A1C28;color:#FCA5A5">RED</span>')
    css_class = "qcard green" if is_green else "qcard"
    return (f'<div class="{css_class}"><div class="qrow"><span>{direction}</span>'
            f'<span>{count} vehicles {badge}</span></div>'
            f'<div class="qbar"><div class="qfill" style="width:{percent:.0f}%;background:{color}"></div></div></div>')


# ====================================================================== SIDEBAR
with st.sidebar:
    st.markdown("### 🚦 Control Panel")
    st.markdown("**Traffic inputs** · vehicles arriving per step")
    rates = {}
    for d in DIRECTIONS:
        rates[d] = st.slider(f"{d} traffic", 0.0, 2.0, DEFAULT_RATES[d], 0.1, key=f"rate_{d}")

    st.markdown("**Add a burst of vehicles**")
    burst_dir = st.selectbox("Road", DIRECTIONS, key="burst_dir")
    burst_n = st.number_input("Vehicles", 1, 20, 5, key="burst_n")
    if st.button("Add vehicles now"):
        st.session_state.env.add_vehicles(burst_dir, burst_n)

    st.divider()
    mode = st.radio("Signal controller", [RL_MODE, FIXED_MODE], key="mode")

    with st.expander("Q-learning settings"):
        alpha = st.slider("Learning rate (alpha)", 0.01, 1.0, 0.10, 0.01)
        gamma = st.slider("Discount factor (gamma)", 0.0, 0.99, 0.90, 0.01)
        eps_start = st.slider("Starting exploration (epsilon)", 0.1, 1.0, 1.0, 0.05)
        episodes = st.slider("Training episodes", 50, 1000, 300, 50)
        steps_per_episode = st.slider("Steps per episode", 50, 300, 100, 10)

    seed = st.number_input("Random seed (used on reset)", 0, 9999, 42)
    col_a, col_b = st.columns(2)
    if col_a.button("Reset sim"):
        st.session_state.env = new_environment(seed)
        st.session_state.history = []
    if col_b.button("Reset agent"):
        st.session_state.agent = QLearningAgent(seed=1)
        st.session_state.train_rewards = []
        st.session_state.comparison = None

ss = st.session_state
env, agent = ss.env, ss.agent
env.arrival_rates = dict(rates)          # slider values take effect immediately

# ======================================================================= HEADER
st.markdown("""
<div class="hero">
  <h1>🚦 Reinforcement Learning-Based Smart Traffic Signal Control</h1>
  <p>A Q-learning agent learns which road should get the green light, using queues,
  dictionaries, tuples and lists · Data Structures Lab mini-project</p>
</div>
""", unsafe_allow_html=True)

# ===================================================================== BUTTONS
b1, b2, b3, b4 = st.columns([1.1, 1, 0.7, 1.2])
train_clicked = b1.button("🎓 Train Agent")
step_clicked = b2.button("▶ Run 1 Step")
n_steps = b3.number_input("Number of steps", 2, 500, 20, label_visibility="collapsed")
multi_clicked = b4.button("⏩ Run Multiple Steps")

if train_clicked:
    run_training(alpha, gamma, eps_start, episodes, steps_per_episode)
if step_clicked:
    simulate_step(mode)
if multi_clicked:
    for _ in range(int(n_steps)):
        simulate_step(mode)

if mode == RL_MODE and not ss.train_rewards:
    st.warning("The agent is untrained, so it acts randomly. Click **Train Agent** first.")

# ======================================================================== KPIs
last = ss.history[-1] if ss.history else None
signal = env.current_signal
total_cleared = env.total_cleared
cards = st.columns(6)
cards[0].markdown(kpi("Current signal", f"{signal or '—'}",
                      "green light" if signal else "no step yet", GREEN), unsafe_allow_html=True)
cards[1].markdown(kpi("Time step", env.step_count, mode, BLUE), unsafe_allow_html=True)
cards[2].markdown(kpi("Last reward", f"{last['reward']:.1f}" if last else "—",
                      "this step", LIGHT_BLUE), unsafe_allow_html=True)
cards[3].markdown(kpi("Total reward", f"{last['cumulative_reward']:,.0f}" if last else "—",
                      "since reset", GREEN), unsafe_allow_html=True)
cards[4].markdown(kpi("Vehicles waiting", env.total_waiting(), "all four roads", AMBER),
                  unsafe_allow_html=True)
cards[5].markdown(kpi("Vehicles cleared", total_cleared, "since reset", BLUE),
                  unsafe_allow_html=True)
st.write("")

# ===================================================================== MAIN VIEW
left, right = st.columns([1.15, 1])
with left:
    show_html(intersection_html(env.queues, signal), 560)

with right:
    st.markdown("#### Queue sizes")
    sizes = env.queue_sizes()
    st.markdown("".join(queue_card(d, sizes[d], d == signal) for d in DIRECTIONS),
                unsafe_allow_html=True)

    state = env.get_state()
    levels = ", ".join(f"{d[0]}: {LEVEL_NAMES[state[i]]}" for i, d in enumerate(DIRECTIONS))
    st.markdown("#### Agent's next decision")
    st.caption(f"State tuple `{state}` → {levels}")
    q_values = agent.get_q_values(state)
    best = max(q_values)
    q_df = pd.DataFrame({"Green for": DIRECTIONS,
                         "Q-value": [round(v, 2) for v in q_values],
                         "Best?": ["✅" if v == best and best != 0 else "" for v in q_values]})
    st.dataframe(q_df, hide_index=True)
    if all(v == 0 for v in q_values):
        st.caption("This state is new to the agent (all Q-values are 0).")

st.write("")

# ======================================================================== TABS
tab_live, tab_train, tab_history, tab_ds = st.tabs(
    ["📊 Live performance", "🎓 Training & comparison", "🧾 History & CSV export", "🧠 Data structures"])

# ------------------------------------------------------------ live performance
with tab_live:
    if not ss.history:
        st.info("Run a step to see performance charts.")
    else:
        df = pd.DataFrame(ss.history)
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**Queue size per road**")
            st.line_chart(df, x="step", y=list(DIRECTIONS), color=CHART_COLORS)
        with c2:
            st.markdown("**Total vehicles waiting**")
            st.area_chart(df, x="step", y="total_queue", color=BLUE)
        c3, c4 = st.columns(2)
        with c3:
            st.markdown("**Reward per step**")
            st.line_chart(df, x="step", y="reward", color=GREEN)
        with c4:
            st.markdown("**Cumulative reward**")
            st.line_chart(df, x="step", y="cumulative_reward", color=LIGHT_BLUE)
        st.markdown("**Green-light usage (steps per road)**")
        usage = df["signal"].value_counts().reindex(DIRECTIONS, fill_value=0)
        st.bar_chart(usage, color=GREEN)

# --------------------------------------------------------- training & comparison
with tab_train:
    m1, m2, m3 = st.columns(3)
    m1.metric("Training episodes done", len(ss.train_rewards))
    m2.metric("States in Q-table", f"{len(agent.q_table):,}")
    m3.metric("Current epsilon", f"{agent.epsilon:.2f}")

    if ss.train_rewards:
        tr = pd.DataFrame({"episode": range(1, len(ss.train_rewards) + 1),
                           "reward": ss.train_rewards})
        tr["moving average (10)"] = tr["reward"].rolling(10, min_periods=1).mean()
        st.markdown("**Reward per training episode** (should rise as the agent learns)")
        st.line_chart(tr, x="episode", y=["reward", "moving average (10)"],
                      color=["#35508f", GREEN])
    else:
        st.info("Click **Train Agent** to start learning. The reward curve will appear here.")

    st.markdown("#### RL agent vs fixed-time signals")
    st.caption("Runs 5 simulations of 200 steps with your current traffic sliders, "
               "using identical traffic for both controllers.")
    if st.button("Run comparison"):
        ss.comparison = {
            "rl": evaluate(agent, rates, "rl"),
            "fixed": evaluate(agent, rates, "fixed"),
        }
    if ss.comparison:
        rl, fx = ss.comparison["rl"], ss.comparison["fixed"]

        def change(a, b):
            return f"{(a - b) / b * 100:+.0f}% vs fixed-time" if b else None

        k1, k2, k3 = st.columns(3)
        k1.metric("Avg queue length", f"{rl['avg_queue']:.1f}", change(rl["avg_queue"], fx["avg_queue"]),
                  delta_color="inverse")
        k2.metric("Avg waiting time (steps)", f"{rl['avg_wait']:.1f}", change(rl["avg_wait"], fx["avg_wait"]),
                  delta_color="inverse")
        k3.metric("Throughput (cars/step)", f"{rl['throughput']:.2f}",
                  change(rl["throughput"], fx["throughput"]))
        table = pd.DataFrame({"Controller": ["Q-learning", "Fixed-time"],
                              "Avg queue": [rl["avg_queue"], fx["avg_queue"]],
                              "Avg wait": [rl["avg_wait"], fx["avg_wait"]]}).set_index("Controller")
        g1, g2 = st.columns(2)
        g1.bar_chart(table[["Avg queue"]], color=BLUE)
        g2.bar_chart(table[["Avg wait"]], color=GREEN)

# ------------------------------------------------------------------ history/CSV
with tab_history:
    if not ss.history:
        st.info("No simulation history yet. Use **Run 1 Step** or **Run Multiple Steps**.")
    else:
        df = pd.DataFrame(ss.history)
        st.dataframe(df.iloc[::-1], hide_index=True)       # newest first
        h1, h2 = st.columns(2)
        h1.download_button("⬇ Download history (CSV)", df.to_csv(index=False).encode("utf-8"),
                           file_name="traffic_simulation_history.csv", mime="text/csv")
        if h2.button("Clear history"):
            ss.history = []
            st.rerun()

# -------------------------------------------------------------- data structures
with tab_ds:
    st.markdown("#### Where each data structure is used")
    st.table(pd.DataFrame([
        ("deque (queue)", "env.queues[direction]", "FIFO: vehicles enter at the back (append) and leave from the front (popleft)."),
        ("dict", "env.queues, arrival_rates, agent.q_table", "Fast lookup by key: road name → queue, state → Q-values."),
        ("tuple", "DIRECTIONS, state, vehicle (id, arrival_step)", "Immutable and hashable, so a state tuple can be a dict key."),
        ("list", "history, Q-values, training rewards", "Ordered, growing collections that feed tables and charts."),
    ], columns=["Structure", "Where", "Why"]))

    st.markdown("#### Live look inside the queues (front of the queue first)")
    for d in DIRECTIONS:
        front = list(env.queues[d])[:6]
        st.code(f"{d:<5} deque({front}{' ...' if len(env.queues[d]) > 6 else ''})", language="python")

    st.markdown("#### Q-table (a dictionary)")
    if agent.q_table:
        rows = []
        for s, qs in agent.q_table.items():
            rows.append({
                **{f"{d} level": LEVEL_NAMES[s[i]] for i, d in enumerate(DIRECTIONS)},
                "last green": DIRECTIONS[s[4]] if s[4] < 4 else "none",
                **{f"Q({d})": round(qs[i], 2) for i, d in enumerate(DIRECTIONS)},
                "best action": DIRECTIONS[qs.index(max(qs))],
            })
        q_table_df = pd.DataFrame(rows)
        st.caption(f"Showing 15 of {len(q_table_df):,} states.")
        st.dataframe(q_table_df.head(15), hide_index=True)
        st.download_button("⬇ Download Q-table (CSV)", q_table_df.to_csv(index=False).encode("utf-8"),
                           file_name="q_table.csv", mime="text/csv")
    else:
        st.info("The Q-table is empty. Train the agent to fill it.")
