# 🚦 Reinforcement Learning-Based Smart Traffic Signal Control System

A beginner-friendly **Data Structures Lab mini-project** built with **Python + Streamlit**.
A Q-learning agent learns which road (North, South, East or West) should receive the
green light so that vehicles wait less at a four-way intersection.

## Features

- Four-way intersection with animated-style traffic lights and moving cars
- Adjustable traffic for every road, plus a "burst of vehicles" button
- Working **Q-learning** agent (epsilon-greedy, Q-table stored in a dictionary)
- Buttons: **Train Agent**, **Run 1 Step**, **Run Multiple Steps**
- Live queue sizes, current signal, reward and cumulative reward
- Performance charts, training curve, and **RL vs fixed-time** comparison
- Simulation history table with **CSV export** (and Q-table CSV export)
- Dark navy / blue / green dashboard theme

## Quick start

```bash
# 1. (optional) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS / Linux

# 2. install dependencies
pip install -r requirements.txt

# 3. run the app
streamlit run app.py
```

The dashboard opens at <http://localhost:8501>. Python 3.9 or newer is recommended.

## How to use it

1. Click **🎓 Train Agent** (about a second). The reward curve appears in the *Training & comparison* tab.
2. Move the **traffic sliders** in the sidebar to change how busy each road is.
3. Click **▶ Run 1 Step** to watch a single decision, or choose a number and click **⏩ Run Multiple Steps**.
4. Open **Run comparison** to see the agent beat the fixed-time signal on average queue length and waiting time.
5. Download the simulation history from the *History & CSV export* tab.

Tip: in the sidebar you can switch the controller to **Fixed-time baseline** to compare behaviour visually.

## Project structure

```
rl-traffic-signal/
├── app.py            # Streamlit dashboard (UI, charts, SVG intersection)
├── traffic_env.py    # Intersection simulation (deque queues, dicts, tuples)
├── q_agent.py        # Q-learning agent (Q-table is a dict)
├── trainer.py        # Training loop, fixed-time baseline, evaluation
├── requirements.txt
├── README.md
└── .streamlit/config.toml   # dark navy / blue / green theme
```

## How the reinforcement learning works

| Concept | In this project |
|---|---|
| **Environment** | One four-way intersection, one road is green per time step |
| **State** | Tuple `(level_N, level_S, level_E, level_W, current_green)`; each level is Low / Medium / High / Very high (queue length 0-2 / 3-6 / 7-12 / 13+) |
| **Action** | Which road gets the green light (0 = North ... 3 = West) |
| **Reward** | `2 × vehicles cleared − 0.5 × vehicles waiting − 1 if the signal switched` |
| **Learning rule** | `Q(s,a) ← Q(s,a) + α · (reward + γ · max Q(s',·) − Q(s,a))` |
| **Exploration** | Epsilon-greedy: epsilon starts at 1.0 and falls to 0.05 during training |

The green road releases up to 4 vehicles per step (3 if the light just switched, which
models the yellow phase). Vehicles arrive randomly (Poisson distribution) at the rate set by the sliders.

## Data structures used

| Structure | Where | Why |
|---|---|---|
| `deque` (queue) | `env.queues[direction]` | FIFO: `append` when a car arrives, `popleft` when it leaves |
| `dict` | `env.queues`, arrival rates, `agent.q_table` | Fast lookup by key (road name or state) |
| `tuple` | `DIRECTIONS`, the RL state, vehicle `(id, arrival_step)` | Immutable and hashable, so a state can be a dictionary key |
| `list` | history records, Q-values, episode rewards | Ordered collections that feed tables and charts |

The *Data structures* tab in the app shows the live contents of every queue and of the Q-table.

## Settings you can experiment with

- **Learning rate (alpha)**, **discount factor (gamma)**, **epsilon**, **episodes** and **steps per episode** (sidebar → *Q-learning settings*)
- Constants at the top of `traffic_env.py`: `DISCHARGE_PER_STEP`, `MAX_QUEUE`, `SWITCH_PENALTY`, `LEVEL_LIMITS`
- The reward formula in `TrafficIntersection.step()`

## Troubleshooting

- **`streamlit: command not found`** → use `python -m streamlit run app.py`.
- **Agent seems random** → it is untrained; click *Train Agent* first (or *Reset agent* then train again).
- **Cars not animating** → the animation runs in your browser; make sure the page is not blocked by an extension.
- **Port already in use** → `streamlit run app.py --server.port 8502`.

## Possible extensions

- Add an emergency-vehicle priority lane
- Let two opposite roads share a green phase
- Replace the Q-table with a small neural network (Deep Q-Network)
- Compare different reward functions in the report
