"""
q_agent.py
==========
A tiny, readable Q-learning agent.

The Q-table is a Python dictionary:
    key   = state  (a tuple, e.g. (2, 0, 3, 1, 2))
    value = list of 4 Q-values, one per action (green for North/South/East/West)

Q-learning update rule (the heart of the algorithm):
    Q(s, a) <- Q(s, a) + alpha * ( reward + gamma * max(Q(s', all actions)) - Q(s, a) )
"""

import random


class QLearningAgent:
    def __init__(self, n_actions=4, alpha=0.1, gamma=0.9,
                 epsilon=1.0, epsilon_min=0.05, seed=None):
        self.n_actions = n_actions
        self.alpha = alpha            # learning rate: how fast new info replaces old
        self.gamma = gamma            # discount factor: how much future reward matters
        self.epsilon = epsilon        # exploration rate: chance of a random action
        self.epsilon_min = epsilon_min
        self.q_table = {}             # dict: state -> [Q(a0), Q(a1), Q(a2), Q(a3)]
        self.rng = random.Random(seed)

    # ---------------------------------------------------------------- reading
    def get_q_values(self, state):
        """Return a copy of the Q-values of a state (zeros if never seen)."""
        return list(self.q_table.get(state, [0.0] * self.n_actions))

    # --------------------------------------------------------------- decision
    def choose_action(self, state, explore=True):
        """Epsilon-greedy: explore with probability epsilon, otherwise exploit."""
        if explore and self.rng.random() < self.epsilon:
            return self.rng.randrange(self.n_actions)          # explore
        values = self.get_q_values(state)
        best = max(values)
        best_actions = [a for a, v in enumerate(values) if v == best]
        return self.rng.choice(best_actions)                   # exploit (ties random)

    # --------------------------------------------------------------- learning
    def update(self, state, action, reward, next_state):
        """Apply the Q-learning update rule for one experience."""
        row = self.q_table.setdefault(state, [0.0] * self.n_actions)
        best_next = max(self.get_q_values(next_state))
        row[action] += self.alpha * (reward + self.gamma * best_next - row[action])

    def set_epsilon_schedule(self, episodes, start=1.0, fraction=0.8):
        """
        Make epsilon fall smoothly from `start` to `epsilon_min` during the first
        `fraction` of the training episodes. Returns the per-episode multiplier.
        """
        self.epsilon = start
        if episodes <= 1 or start <= self.epsilon_min:
            return 1.0
        return (self.epsilon_min / start) ** (1.0 / max(1, int(episodes * fraction)))

    def decay_epsilon(self, decay):
        self.epsilon = max(self.epsilon_min, self.epsilon * decay)
