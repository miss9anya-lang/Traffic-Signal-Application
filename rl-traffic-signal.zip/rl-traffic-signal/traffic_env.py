"""
traffic_env.py
==============
Simulation of a four-way traffic intersection (North, South, East, West).

Data structures used (great for a Data Structures Lab report):
  * tuple  -> DIRECTIONS (fixed order), the RL state, a vehicle (id, arrival_step)
  * dict   -> direction -> queue, direction -> arrival rate, step information
  * deque  -> one FIFO queue of waiting vehicles per road (collections.deque)
  * list   -> results and history records

Rules of the simulation
  * Exactly ONE road has the green light in every time step.
  * The green road lets up to DISCHARGE_PER_STEP vehicles leave (dequeue).
    If the signal had to switch to a new road, 1 vehicle of capacity is lost
    (a "yellow-light" penalty) and the reward is reduced.
  * New vehicles arrive on every road (random, Poisson distributed).
"""

import itertools
import math
import random
from collections import deque

# A tuple: the order never changes, and the index of a direction = the RL action.
DIRECTIONS = ("North", "South", "East", "West")

# Average number of vehicles arriving per step on each road (dict).
DEFAULT_RATES = {"North": 0.6, "South": 0.5, "East": 0.9, "West": 0.4}

DISCHARGE_PER_STEP = 4     # vehicles that can leave per green step
MAX_QUEUE = 30             # a road can hold at most this many vehicles
SWITCH_PENALTY = 1.0       # reward penalty when the green light changes road

# Queue length -> level (used to keep the number of RL states small).
#   0..2 -> 0 (Low) | 3..6 -> 1 (Medium) | 7..12 -> 2 (High) | 13+ -> 3 (Very high)
LEVEL_LIMITS = (2, 6, 12)
LEVEL_NAMES = ("Low", "Medium", "High", "Very high")


def queue_level(length):
    """Convert a queue length into a level number (0-3)."""
    for level, limit in enumerate(LEVEL_LIMITS):
        if length <= limit:
            return level
    return len(LEVEL_LIMITS)


class TrafficIntersection:
    """A four-way intersection. Each road owns a deque of waiting vehicles."""

    def __init__(self, arrival_rates=None, seed=None, discharge=DISCHARGE_PER_STEP):
        self.rng = random.Random(seed)
        self.arrival_rates = dict(arrival_rates or DEFAULT_RATES)
        self.discharge = discharge
        self.reset()

    # ------------------------------------------------------------------ setup
    def reset(self):
        """Empty all roads and restart the counters."""
        self.queues = {d: deque() for d in DIRECTIONS}   # dict of deques
        self._ids = itertools.count(1)                   # vehicle id generator
        self.step_count = 0
        self.current_signal = None                       # nobody is green yet
        self.total_cleared = 0
        self.total_wait = 0

    def add_vehicles(self, direction, count):
        """Append `count` vehicles to the BACK of a road's queue (enqueue)."""
        added = 0
        for _ in range(int(count)):
            if len(self.queues[direction]) < MAX_QUEUE:
                # a vehicle is a tuple: (vehicle_id, step_when_it_arrived)
                self.queues[direction].append((next(self._ids), self.step_count))
                added += 1
        return added

    # --------------------------------------------------------------- readings
    def queue_sizes(self):
        return {d: len(self.queues[d]) for d in DIRECTIONS}

    def total_waiting(self):
        return sum(len(q) for q in self.queues.values())

    def get_state(self):
        """
        The RL state is a tuple of 5 numbers:
          (level_N, level_S, level_E, level_W, index_of_current_green)
        Tuples are immutable and hashable, so they can be dictionary keys
        in the Q-table.
        """
        levels = tuple(queue_level(len(self.queues[d])) for d in DIRECTIONS)
        signal_index = DIRECTIONS.index(self.current_signal) if self.current_signal else 4
        return levels + (signal_index,)

    # ------------------------------------------------------------ simulation
    def _poisson(self, lam):
        """Random number of arrivals with average `lam` (Knuth's algorithm)."""
        limit = math.exp(-lam)
        k, p = 0, 1.0
        while True:
            p *= self.rng.random()
            if p <= limit:
                return k
            k += 1

    def step(self, action):
        """
        Give the green light to DIRECTIONS[action] for one time step.
        Returns (next_state, reward, info).
        """
        signal = DIRECTIONS[action]
        switched = self.current_signal is not None and signal != self.current_signal
        capacity = max(1, self.discharge - (1 if switched else 0))

        # 1) Departures: dequeue vehicles from the FRONT of the green road.
        cleared = 0
        road = self.queues[signal]
        while road and cleared < capacity:
            _vehicle_id, arrived_at = road.popleft()
            self.total_wait += self.step_count - arrived_at
            cleared += 1
        self.total_cleared += cleared

        # 2) Arrivals: enqueue new vehicles at the BACK of every road.
        arrived = 0
        for d in DIRECTIONS:
            arrived += self.add_vehicles(d, self._poisson(self.arrival_rates[d]))

        self.step_count += 1
        self.current_signal = signal

        # 3) Reward: reward cleared vehicles, punish waiting vehicles & switching.
        total_queue = self.total_waiting()
        reward = 2.0 * cleared - 0.5 * total_queue - (SWITCH_PENALTY if switched else 0.0)

        info = {
            "signal": signal,
            "switched": switched,
            "cleared": cleared,
            "arrived": arrived,
            "queues": self.queue_sizes(),
            "total_queue": total_queue,
        }
        return self.get_state(), reward, info
