"""
trainer.py
==========
Training loop for the Q-learning agent, a fixed-time baseline controller,
and an evaluation helper used to compare both controllers.
"""

import random

from traffic_env import DIRECTIONS, TrafficIntersection


def fixed_time_action(step, green_time=5):
    """Baseline: give each road 5 green steps in turn (N, S, E, W, N, ...)."""
    return (step // green_time) % len(DIRECTIONS)


def train(agent, episodes=300, steps_per_episode=100, epsilon_start=1.0,
          seed=0, progress_callback=None):
    """
    Train `agent` for several episodes. Each episode uses random traffic
    (different arrival rates) so the agent learns to handle many situations.
    Returns a list with the total reward of every episode.
    """
    rng = random.Random(seed)
    decay = agent.set_epsilon_schedule(episodes, start=epsilon_start)
    episode_rewards = []

    for episode in range(1, episodes + 1):
        rates = {d: rng.uniform(0.1, 1.2) for d in DIRECTIONS}
        env = TrafficIntersection(rates, seed=rng.randrange(10 ** 6))
        for d in DIRECTIONS:                       # start with a few cars waiting
            env.add_vehicles(d, rng.randint(0, 8))

        state = env.get_state()
        total_reward = 0.0
        for _ in range(steps_per_episode):
            action = agent.choose_action(state, explore=True)
            next_state, reward, _info = env.step(action)
            agent.update(state, action, reward, next_state)
            state = next_state
            total_reward += reward

        agent.decay_epsilon(decay)
        episode_rewards.append(total_reward)
        if progress_callback:
            progress_callback(episode, episodes, total_reward)

    return episode_rewards


def evaluate(agent, rates, mode, steps=200, runs=5, seed=100, green_time=5):
    """
    Run `runs` simulations of `steps` steps and return average results.
    mode = "rl" (greedy Q-learning agent) or "fixed" (fixed-time baseline).
    The same seeds are used for both modes, so traffic arrivals are identical.
    """
    avg_queues, avg_waits, throughputs, rewards = [], [], [], []
    for run in range(runs):
        env = TrafficIntersection(rates, seed=seed + run)
        state = env.get_state()
        queue_sum = 0
        reward_sum = 0.0
        for t in range(steps):
            if mode == "rl":
                action = agent.choose_action(state, explore=False)
            else:
                action = fixed_time_action(t, green_time)
            state, reward, info = env.step(action)
            queue_sum += info["total_queue"]
            reward_sum += reward
        avg_queues.append(queue_sum / steps)
        avg_waits.append(env.total_wait / env.total_cleared if env.total_cleared else 0.0)
        throughputs.append(env.total_cleared / steps)
        rewards.append(reward_sum)

    def mean(values):
        return sum(values) / len(values)

    return {
        "avg_queue": mean(avg_queues),
        "avg_wait": mean(avg_waits),
        "throughput": mean(throughputs),
        "total_reward": mean(rewards),
    }
